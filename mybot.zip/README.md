# Hectee Multi-Purpose Bot

Discord.js bot with verification, moderation, automod, private event logs, role buttons, welcome/auto-role onboarding, saved text tags, and private support tickets. Admins configure it with slash commands; no source edits are needed for routine server setup.

The project also includes a responsive, OAuth-protected web dashboard for server selection, plugin controls, feature settings, saved tags, log destinations, and a live welcome-message/embed studio. It uses the same `data.json` store as the bot.

## One-Time Requirements

- A Discord application and a server where you have **Manage Server**.
- Node.js 20 or newer on an always-on Node.js host. A Codespace can run it for testing, but the bot disconnects when the Codespace stops.
- A bot invite with the `bot` and `applications.commands` scopes and these permissions: **Administrator** is the simplest first setup. For a narrower invite, grant **Manage Roles**, **Manage Channels**, **Manage Messages**, **Ban Members**, **Kick Members**, **Moderate Members**, **View Channels**, **Send Messages**, **Embed Links**, **Read Message History**, and **Manage Webhooks** is not needed.
- In Discord Developer Portal → your application → **Bot** → **Privileged Gateway Intents**, turn on **Server Members Intent** and **Message Content Intent**. Message Content is required for automod, `!tag` triggers, and reliable text logging. Discord may require approval for larger verified bots.

Invite the bot, then move its role above every role it needs to assign or moderate. Keep the token secret. `.env.example` contains placeholders; replace them with your application's and server's IDs.

## Start the Bot

In the project terminal, copy `.env.example` to `.env`, then fill in `DISCORD_TOKEN`, `CLIENT_ID`, `GUILD_ID`, `UNVERIFIED_ROLE_ID`, `MEMBER_ROLE_ID`, and `VERIFICATION_CHANNEL_ID`. Enable Developer Mode in Discord and use **Copy Server ID**, **Copy User ID**, and **Copy Channel ID** as needed. Never paste the bot token into chat or commit `.env`. A live token was present in the old example file; revoke/regenerate it in the Developer Portal before deployment.

### Dashboard OAuth

1. In the [Discord Developer Portal](https://discord.com/developers/applications), open this same application and go to **OAuth2 → General**.
2. Copy its **Client Secret** into the private `.env` value `OAUTH_CLIENT_SECRET`. Do not put a secret in `.env.example`, the dashboard, or a public host setting.
3. Add the exact callback URL to **Redirects**: `http://localhost:3000/auth/callback` for local testing, `https://YOUR-CODESPACE-3000.app.github.dev/auth/callback` for a forwarded Codespace, or `https://YOUR-DASHBOARD-HOST/auth/callback` for deployment.
4. Set `DASHBOARD_REDIRECT_URI` to that exact same URL. `CLIENT_ID` is used as the OAuth client ID; `DASHBOARD_PORT` defaults to `3000`.
5. On a host, set all of these as private environment variables and use HTTPS. The dashboard uses Discord OAuth (`identify` and `guilds`) and only shows servers where the signed-in user owns the server or has Manage Server permission.

After signing in, choose a server marked **Manage**. A server without the bot has a **Setup** button that opens Discord's bot-install page. Once installed and the bot process is online, refresh the dashboard and select **Manage**.

The dashboard runs in the same process as the Discord bot on port `3000` by default. In Codespaces, open the **Ports** tab, forward port `3000`, and open its HTTPS address on your phone. Use that exact forwarded address in both Discord's redirect list and `DASHBOARD_REDIRECT_URI`. It is disabled until `OAUTH_CLIENT_SECRET` is configured. For permanent use, deploy to a persistent Node.js host with HTTPS and persistent storage for `data.json`; static website hosting is not sufficient.

Run these commands in the terminal:

```sh
npm install
npm run deploy
npm start
```

Keep `npm start` running. For a permanent bot, use a host that supports a persistent Node.js service, connect this project, set the same environment variables in the host's private environment-variable page, and run `npm run deploy` once followed by `npm start` as its start command. Do not use a static website host.

## Discord Setup

The dashboard's **Plugins** pages have touch-friendly channel/role pickers and save directly to `data.json`. Use the message studio to save the Welcomer message and select its destination channel. Feature setup that publishes Discord messages still uses slash commands. For fully in-app setup with Discord mobile, configure these essentials first:

1. `/config set` → **Staff roles** → enter one or more role mentions separated by commas, such as `@Moderator, @Support`.
2. `/setup-modules` → create the private log channel. Run it again after changing staff roles so its access stays current.
3. `/config set` → **Welcome channel** → select the channel for welcome messages.
4. `/config set` → **Rules channel** → select the rules channel.
5. `/config set` → **Welcome text** → write the message; `{user}`, `{server}`, and `{rules}` are replaced automatically.
6. `/config set` → **Join mode** → use `verify` for the existing Unverified/Verify flow, or `instant` to give the configured Member role immediately.
7. `/config set` → **Member role** → mention the role to grant in `instant` mode. If unset, the `MEMBER_ROLE_ID` from `.env` is used.
8. `/config show` displays saved settings.

The bot starts in `verify` mode. These modes are intentionally exclusive: `instant` mode does not give newcomers the Unverified role, so do not use it if restricted channels depend on verification. If you manually choose another Logs channel with `/config set`, make sure its channel permissions are private and grant your staff roles access.

## Modules

- **Moderation:** `/ban`, `/kick`, `/warn`, `/timeout`, and `/purge`. The bot checks moderator permissions and role hierarchy, records warnings, and sends action logs to the configured logs channel. The dashboard toggle gates these commands and Auto-Mod.
- **Auto-Mod:** scans message text for its built-in profanity list, configured blocked words/domains, mention floods, and repeated/high-rate spam. It deletes a match, records a warning, and logs the infraction. Configure additional values in the dashboard's Moderation settings; Message Content Intent must be enabled.
- **Logging:** deletes, edits, joins, leaves, nickname changes, moderation actions, and ticket events can each use their own dashboard-selected destination. `/setup-modules` creates/refreshes a private `#mod-logs`; configure Staff roles first.
- **Role buttons:** `/role-panel create` posts a panel; `/role-panel add` adds a role button to its message. The bot must be above each self-assignable role. One panel supports up to five buttons.
- **Welcome and auto-role:** configure the welcome channel, text, rules, and `verify` or `instant` mode in the dashboard. The Message Studio's embed, fields, links, and select menus are saved and sent on member join.
- **Tags:** create and remove saved tags in the Custom Commands dashboard page. Members call them by sending `!rules` (replace `rules` with the tag name). `/tag` commands remain available. Message Content Intent must be enabled for prefix triggers.
- **Tickets:** `/ticket-panel` posts an **Open Ticket** button. Staff roles must be configured first. Each member gets one private channel; the opener or staff can close it.

## Verification

In `verify` mode, run `/setup-verification`. The bot uses the configured existing roles and channel, allows Unverified members to view only the verification channel, and posts a Verify button. Newly created channels are also hidden from Unverified. This command changes channel permissions, so check its response for channels it could not update. Existing access rules for other roles are left unchanged.

## Important Limits

- Discord bulk-delete cannot remove messages older than 14 days; `/purge` skips those.
- Guild slash commands are registered to the configured `GUILD_ID` by `npm run deploy`.
- `data.json` stores per-server settings and warning/tag/panel/ticket data. Back it up with the host's persistent storage; ephemeral deployments can lose it on restart.
- A custom bot is not fully code-free: this project still needs a Node.js host and the one-time terminal commands above. After deployment, normal configuration and use happen inside Discord.
